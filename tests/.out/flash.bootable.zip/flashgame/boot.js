(function flashBoot(CFG, bundleVfs) {
    (async () => {
      const host = document.getElementById("flash-host");
      const fail = (e) => {
        console.error(e);
        if (host) host.textContent = "Flash bundle error: " + ((e && e.message) || e);
      };
      try {
        document.title = CFG.title;
        // Ruffle keys a game's saves (SharedObjects) by the movie's host and path. Serving each
        // game from its own virtual folder keeps two games that both ship a "game.swf" from
        // overwriting each other's saves.
        const vfs = bundleVfs("https://bundle.invalid" + (CFG.ns ? "/" + encodeURIComponent(CFG.ns) : ""));
        if (!vfs.has(CFG.runtime + "ruffle.js")) throw new Error("The Ruffle runtime is missing from this bundle (" + CFG.runtime + "ruffle.js). Convert the game again.");

        // publicPath points Ruffle's core chunk and WASM requests at the bundle.
        window.RufflePlayer = window.RufflePlayer || {};
        window.RufflePlayer.config = Object.assign({}, window.RufflePlayer.config, CFG.config, { publicPath: vfs.url(CFG.runtime) });
        await vfs.loadScript(CFG.runtime + "ruffle.js");
        if (!window.RufflePlayer || typeof window.RufflePlayer.newest !== "function") throw new Error("Ruffle loaded but did not start.");

        const player = window.RufflePlayer.newest().createPlayer();
        player.style.width = "100%";
        player.style.height = "100%";
        player.style.display = "block";
        host.textContent = "";
        host.style.padding = "0";
        host.appendChild(player);
        // The movie lives at the virtual origin too. Ruffle resolves the SWF's relative requests
        // (loadMovie, XML, sounds) against `base`, which defaults to the page URL, so point it at
        // the movie's own folder in the bundle.
        const dir = CFG.swf.slice(0, CFG.swf.lastIndexOf("/") + 1);
        await player.ruffle().load({ url: vfs.url(CFG.swf), base: vfs.url(dir) });
      } catch (e) {
        fail(e);
      }
    })();
  })({"title":"flashgame","swf":"game.swf","runtime":"_ruffle/","ns":"flashgame","config":{"polyfills":false,"autoplay":"auto","unmuteOverlay":"visible","letterbox":"on","allowFullscreen":true}}, function bundleVfs(ORIGIN) {
    const ROOT = window.__bundleRoot;
    const MIME = {
      js: "text/javascript", mjs: "text/javascript", wasm: "application/wasm", json: "application/json",
      css: "text/css", html: "text/html", txt: "text/plain", xml: "text/xml",
      swf: "application/x-shockwave-flash", flv: "video/x-flv", mp3: "audio/mpeg", ogg: "audio/ogg",
      wav: "audio/wav", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif",
      zip: "application/zip", jsdos: "application/zip"
    };
    const LOWER = new Map();
    ROOT.forEach((rel, f) => { if (!f.dir) LOWER.set(rel.toLowerCase(), rel); });
    const blobs = new Map(), urls = new Map();
    const abs = (u) => { try { return new URL(String(u), document.baseURI).href; } catch (_) { return String(u || ""); } };
    // Bundle path for a virtual URL, or null when the URL is not ours. Old games often get the
    // case of their own file names wrong, so a case-insensitive match is accepted too.
    const pathOf = (u) => {
      const href = abs(u);
      if (href.toLowerCase().indexOf(ORIGIN.toLowerCase() + "/") !== 0) return null;
      let rel = href.slice(ORIGIN.length + 1).split("#")[0].split("?")[0];
      try { rel = decodeURIComponent(rel); } catch (_) {}
      rel = rel.split("/").filter((x) => x && x !== ".").join("/");
      return ROOT.file(rel) ? rel : (LOWER.get(rel.toLowerCase()) || rel);
    };
    const blobFor = (rel) => {
      if (!blobs.has(rel)) {
        const f = ROOT.file(rel);
        const type = MIME[(rel.split(".").pop() || "").toLowerCase()] || "application/octet-stream";
        blobs.set(rel, f ? f.async("blob").then((b) => b.slice(0, b.size, type)) : Promise.resolve(null));
      }
      return blobs.get(rel);
    };
    const urlFor = (rel) => {
      if (!urls.has(rel)) urls.set(rel, blobFor(rel).then((b) => (b ? URL.createObjectURL(b) : null)));
      return urls.get(rel);
    };

    const nativeFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
      const raw = typeof input === "string" ? input : input instanceof URL ? input.href : (input && input.url) || String(input);
      const rel = pathOf(raw);
      if (rel === null) return nativeFetch(input, init);
      return blobFor(rel).then((b) => {
        const res = b
          ? new Response(b, { status: 200, statusText: "OK", headers: { "Content-Type": b.type, "Content-Length": String(b.size) } })
          : new Response("Not in bundle: " + rel, { status: 404, statusText: "Not Found" });
        try { Object.defineProperty(res, "url", { value: abs(raw) }); } catch (_) {}
        return res;
      });
    };

    const XP = XMLHttpRequest.prototype;
    const nOpen = XP.open, nSend = XP.send, nHeader = XP.setRequestHeader, nMime = XP.overrideMimeType;
    XP.open = function (method, url) {
      this.__vfsPath = typeof url === "string" || url instanceof URL ? pathOf(url) : null;
      this.__vfsArgs = arguments; this.__vfsHeaders = []; this.__vfsMime = null;
      if (this.__vfsPath === null) return nOpen.apply(this, arguments);
      return nOpen.call(this, method, "about:blank", true);
    };
    XP.setRequestHeader = function (n, v) {
      if (this.__vfsPath != null) { this.__vfsHeaders.push([n, v]); return; }
      return nHeader.call(this, n, v);
    };
    XP.overrideMimeType = function (m) {
      if (this.__vfsPath != null) { this.__vfsMime = m; return; }
      return nMime.call(this, m);
    };
    XP.send = function (body) {
      const rel = this.__vfsPath;
      if (rel == null) return nSend.call(this, body);
      const xhr = this, args = this.__vfsArgs, type = xhr.responseType;
      urlFor(rel).then((u) => {
        if (!u) throw new Error("Not in bundle: " + rel);
        nOpen.call(xhr, args[0], u, true);
        try { if (type) xhr.responseType = type; } catch (_) {}
        for (const [n, v] of xhr.__vfsHeaders) { try { nHeader.call(xhr, n, v); } catch (_) {} }
        if (xhr.__vfsMime) { try { nMime.call(xhr, xhr.__vfsMime); } catch (_) {} }
        nSend.call(xhr, body);
      }).catch((err) => {
        console.error(err);
        try { xhr.dispatchEvent(new ProgressEvent("error")); } catch (_) {}
        try { xhr.dispatchEvent(new ProgressEvent("loadend")); } catch (_) {}
      });
    };

    // Emulators add their own <script src> tags (Ruffle's core chunk, js-dos's emulators.js).
    const srcDesc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, "src");
    Object.defineProperty(HTMLScriptElement.prototype, "src", {
      configurable: true, enumerable: srcDesc.enumerable, get: srcDesc.get,
      set: function (v) {
        const rel = pathOf(v);
        if (rel === null) return srcDesc.set.call(this, v);
        const el = this;
        urlFor(rel).then((u) => {
          if (u) srcDesc.set.call(el, u);
          else el.dispatchEvent(new Event("error"));
        });
      }
    });

    const url = (rel) => ORIGIN + "/" + rel.split("/").map(encodeURIComponent).join("/");
    return {
      url,
      has: (rel) => Boolean(ROOT.file(rel)),
      text: (rel) => blobFor(rel).then((b) => { if (!b) throw new Error("Not in bundle: " + rel); return b.text(); }),
      loadScript: (rel) => new Promise((resolve, reject) => {
        const s = document.createElement("script");
        s.onload = resolve;
        s.onerror = () => reject(new Error("Could not load " + rel + " from the bundle."));
        s.src = url(rel);
        document.head.appendChild(s);
      })
    };
  });