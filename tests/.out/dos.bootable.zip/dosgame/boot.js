(function dosBoot(CFG, bundleVfs) {
    (async () => {
      const host = document.getElementById("dos");
      const fail = (e) => {
        console.error(e);
        if (host) host.textContent = "DOS bundle error: " + ((e && e.message) || e);
      };
      try {
        const ROOT = window.__bundleRoot;
        document.title = CFG.title;
        const vfs = bundleVfs("https://bundle.invalid");
        if (!vfs.has(CFG.runtime + "js-dos.js")) throw new Error("The js-dos runtime is missing from this bundle (" + CFG.runtime + "js-dos.js). Convert the game again.");

        // Opened straight from disk (file://), the page has an opaque origin and Chromium
        // refuses to load js-dos's audio worklet from a blob: URL, so the game runs silent.
        // A data: URL with the same code is accepted.
        if (location.protocol === "file:" && window.AudioWorklet && AudioWorklet.prototype.addModule) {
          const addModule = AudioWorklet.prototype.addModule;
          AudioWorklet.prototype.addModule = function (url, opts) {
            if (typeof url !== "string" || url.indexOf("blob:") !== 0) return addModule.call(this, url, opts);
            return fetch(url).then((r) => r.text()).then((code) =>
              addModule.call(this, "data:text/javascript;charset=utf-8," + encodeURIComponent(code), opts));
          };
        }

        const css = document.createElement("style");
        css.textContent = await vfs.text(CFG.runtime + "js-dos.css");
        document.head.appendChild(css);
        await vfs.loadScript(CFG.runtime + "js-dos.js");
        if (typeof window.Dos !== "function") throw new Error("js-dos loaded but Dos() is not available.");

        const zf = ROOT.file("game.jsdos");
        if (!zf) throw new Error("game.jsdos is missing from this bundle.");
        const url = URL.createObjectURL(new Blob([await zf.async("uint8array")], { type: "application/zip" }));
        const saves = window.__quantiSaves && window.__quantiSaves.active ? window.__quantiSaves : null;

        host.textContent = "";
        const props = window.Dos(host, {
          url,
          pathPrefix: vfs.url(CFG.runtime + "emulators/"),
          // Only the classic DOSBox core is packed; keep js-dos from switching to DOSBox-X.
          backend: "dosbox",
          backendLocked: true,
          // Saved progress (the disk changes js-dos records) goes to QuantiLoader's save guard,
          // which backs it up to Saves/<game>/. js-dos's own store (OPFS) is unavailable when the
          // page is opened from disk, where saving would otherwise fail silently. Outside
          // QuantiLoader, fall back to js-dos's store under a stable key (the bundle URL is a
          // fresh blob: URL every run).
          fsChanges: saves
            ? { pull: async () => saves.readFile("dos-changes"), push: async (_url, data) => saves.writeFile("dos-changes", data) }
            : { local: true, urlToKey: async () => CFG.key }
        });
        window.__dosProps = props;
        try { props.setNoCloud(true); } catch (_) {}
      } catch (e) {
        fail(e);
      }
    })();
  })({"title":"dosgame","runtime":"_jsdos/","key":"bootloader:dosgame"}, function bundleVfs(ORIGIN) {
    const ROOT = window.__bundleRoot;
    const MIME = {
      js: "text/javascript", mjs: "text/javascript", wasm: "application/wasm", json: "application/json",
      css: "text/css", html: "text/html", txt: "text/plain", xml: "text/xml",
      swf: "application/x-shockwave-flash", flv: "video/x-flv", mp3: "audio/mpeg", ogg: "audio/ogg",
      wav: "audio/wav", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif",
      zip: "application/zip", jsdos: "application/zip"
    };
    const LOWER = new Map();
    ROOT.forEach((rel, f) => { if (!f.dir) LOWER.set(rel.toLowerCase(), rel); });
    const blobs = new Map(), urls = new Map();
    const abs = (u) => { try { return new URL(String(u), document.baseURI).href; } catch (_) { return String(u || ""); } };
    // Bundle path for a virtual URL, or null when the URL is not ours. Old games often get the
    // case of their own file names wrong, so a case-insensitive match is accepted too.
    const pathOf = (u) => {
      const href = abs(u);
      if (href.toLowerCase().indexOf(ORIGIN.toLowerCase() + "/") !== 0) return null;
      let rel = href.slice(ORIGIN.length + 1).split("#")[0].split("?")[0];
      try { rel = decodeURIComponent(rel); } catch (_) {}
      rel = rel.split("/").filter((x) => x && x !== ".").join("/");
      return ROOT.file(rel) ? rel : (LOWER.get(rel.toLowerCase()) || rel);
    };
    const blobFor = (rel) => {
      if (!blobs.has(rel)) {
        const f = ROOT.file(rel);
        const type = MIME[(rel.split(".").pop() || "").toLowerCase()] || "application/octet-stream";
        blobs.set(rel, f ? f.async("blob").then((b) => b.slice(0, b.size, type)) : Promise.resolve(null));
      }
      return blobs.get(rel);
    };
    const urlFor = (rel) => {
      if (!urls.has(rel)) urls.set(rel, blobFor(rel).then((b) => (b ? URL.createObjectURL(b) : null)));
      return urls.get(rel);
    };

    const nativeFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
      const raw = typeof input === "string" ? input : input instanceof URL ? input.href : (input && input.url) || String(input);
      const rel = pathOf(raw);
      if (rel === null) return nativeFetch(input, init);
      return blobFor(rel).then((b) => {
        const res = b
          ? new Response(b, { status: 200, statusText: "OK", headers: { "Content-Type": b.type, "Content-Length": String(b.size) } })
          : new Response("Not in bundle: " + rel, { status: 404, statusText: "Not Found" });
        try { Object.defineProperty(res, "url", { value: abs(raw) }); } catch (_) {}
        return res;
      });
    };

    const XP = XMLHttpRequest.prototype;
    const nOpen = XP.open, nSend = XP.send, nHeader = XP.setRequestHeader, nMime = XP.overrideMimeType;
    XP.open = function (method, url) {
      this.__vfsPath = typeof url === "string" || url instanceof URL ? pathOf(url) : null;
      this.__vfsArgs = arguments; this.__vfsHeaders = []; this.__vfsMime = null;
      if (this.__vfsPath === null) return nOpen.apply(this, arguments);
      return nOpen.call(this, method, "about:blank", true);
    };
    XP.setRequestHeader = function (n, v) {
      if (this.__vfsPath != null) { this.__vfsHeaders.push([n, v]); return; }
      return nHeader.call(this, n, v);
    };
    XP.overrideMimeType = function (m) {
      if (this.__vfsPath != null) { this.__vfsMime = m; return; }
      return nMime.call(this, m);
    };
    XP.send = function (body) {
      const rel = this.__vfsPath;
      if (rel == null) return nSend.call(this, body);
      const xhr = this, args = this.__vfsArgs, type = xhr.responseType;
      urlFor(rel).then((u) => {
        if (!u) throw new Error("Not in bundle: " + rel);
        nOpen.call(xhr, args[0], u, true);
        try { if (type) xhr.responseType = type; } catch (_) {}
        for (const [n, v] of xhr.__vfsHeaders) { try { nHeader.call(xhr, n, v); } catch (_) {} }
        if (xhr.__vfsMime) { try { nMime.call(xhr, xhr.__vfsMime); } catch (_) {} }
        nSend.call(xhr, body);
      }).catch((err) => {
        console.error(err);
        try { xhr.dispatchEvent(new ProgressEvent("error")); } catch (_) {}
        try { xhr.dispatchEvent(new ProgressEvent("loadend")); } catch (_) {}
      });
    };

    // Emulators add their own <script src> tags (Ruffle's core chunk, js-dos's emulators.js).
    const srcDesc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, "src");
    Object.defineProperty(HTMLScriptElement.prototype, "src", {
      configurable: true, enumerable: srcDesc.enumerable, get: srcDesc.get,
      set: function (v) {
        const rel = pathOf(v);
        if (rel === null) return srcDesc.set.call(this, v);
        const el = this;
        urlFor(rel).then((u) => {
          if (u) srcDesc.set.call(el, u);
          else el.dispatchEvent(new Event("error"));
        });
      }
    });

    const url = (rel) => ORIGIN + "/" + rel.split("/").map(encodeURIComponent).join("/");
    return {
      url,
      has: (rel) => Boolean(ROOT.file(rel)),
      text: (rel) => blobFor(rel).then((b) => { if (!b) throw new Error("Not in bundle: " + rel); return b.text(); }),
      loadScript: (rel) => new Promise((resolve, reject) => {
        const s = document.createElement("script");
        s.onload = resolve;
        s.onerror = () => reject(new Error("Could not load " + rel + " from the bundle."));
        s.src = url(rel);
        document.head.appendChild(s);
      })
    };
  });