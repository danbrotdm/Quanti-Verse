
const n = Number(localStorage.getItem('sg_count') || 0) + 1;
localStorage.setItem('sg_count', String(n));
localStorage.sg_prop = 'launch-' + n;            // property-style write, bypasses setItem
const colors = ['#000', '#ff0000', '#00ff00', '#0000ff'];
document.getElementById('run').style.background = colors[Math.min(n, 3)];
const req = indexedDB.open('sgdb', 1);
req.onupgradeneeded = () => req.result.createObjectStore('s');
req.onsuccess = () => {
  const db = req.result, tx = db.transaction('s', 'readwrite'), os = tx.objectStore('s');
  const g = os.get('slot1');
  g.onsuccess = () => {
    document.getElementById('idb').style.background = g.result ? '#00ff00' : '#ff0000';
    os.put({ count: n, bytes: new Uint8Array([1, 2, 3, n]), when: new Date() }, 'slot1');
  };
  tx.oncomplete = () => { document.title = 'saved ' + n; };
};
