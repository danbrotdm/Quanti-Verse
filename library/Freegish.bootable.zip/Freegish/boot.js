(async()=>{try{
const ROOT=window.__bundleRoot;
const ENTRY="index.html";
const FILES=new Set(["index.wasm","index.html","index.js","index.data"]);
const CACHE=new Map();

      const clean=(p)=>{
        p=String(p||"").replace(/\\/g,"/");
        const out=[];
        for(const x of p.split("/")){
          if(!x||x===".")continue;
          if(x===".."){if(out.length)out.pop();continue;}
          out.push(x);
        }
        return out.join("/");
      };
    

      const VORIGIN="https://bundle.invalid";
      const external0=(u)=>/^(?:https?:|ftp:|file:|data:|blob:|javascript:|mailto:|tel:|\/\/)/i.test(String(u||""));
    

      const ENTRYDIR=ENTRY.slice(0,ENTRY.lastIndexOf("/")+1);
      const PAGEDIR=location.href.replace(/[?#].*$/,"").replace(/[^\/]*$/,"");
      // Absolute URLs an engine builds from the page's own location (http://host/dir/x.worker.js,
      // or a made-up blob:host/x.worker.js from a blob: script URL): the game believes it lives
      // at ENTRY, so these point into the bundle.
      const pageRel=(u)=>{
        u=String(u||"");
        let r=null;
        if(PAGEDIR&&u.indexOf(PAGEDIR)===0)r=u.slice(PAGEDIR.length);
        else{const m=/^blob:(?:[a-z-]+:\/\/[^\/]+|null)\/(.+)$/i.exec(u);if(m&&/\.[a-z0-9]+$/i.test(m[1].split(/[?#]/)[0]))r=m[1];}
        if(r===null)return null;
        r=r.split("#")[0].split("?")[0];
        try{r=decodeURIComponent(r);}catch(_){}
        return r;
      };
      const external=(u)=>{
        u=String(u||"");
        if(u.indexOf(VORIGIN+"/")===0)return false;
        const r=pageRel(u);
        if(r!==null&&FILES.has(clean(ENTRYDIR+r)))return false;
        return external0(u);
      };
      const resolve=(base,ref)=>{
        ref=String(ref||"").trim();
        if(ref.indexOf(VORIGIN+"/")===0){try{return clean(decodeURIComponent(new URL(ref).pathname));}catch(_){return null;}}
        const pr=pageRel(ref);
        if(pr!==null){const p=clean(ENTRYDIR+pr);if(FILES.has(p))return p;}
        if(!ref||ref.startsWith("#")||external(ref))return null;
        ref=ref.split("#")[0].split("?")[0];
        if(!ref)return null;
        const i=base.lastIndexOf("/");
        const b=i<0?"":base.slice(0,i+1);
        return clean(b+ref);
      };
    

      const MIME={wasm:"application/wasm",js:"text/javascript",mjs:"text/javascript",json:"application/json",html:"text/html",htm:"text/html",css:"text/css",txt:"text/plain",xml:"text/xml",png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp",svg:"image/svg+xml",ogg:"audio/ogg",mp3:"audio/mpeg",wav:"audio/wav",mp4:"video/mp4",webm:"video/webm",woff:"font/woff",woff2:"font/woff2",ttf:"font/ttf"};
      const BIG=16*1024*1024;
      async function blobFor(path){
        const f=ROOT.file(path);
        if(!f)return null;
        const b=await f.async("blob");
        const t=MIME[path.split(".").pop().toLowerCase()];
        // Blob.slice with a type re-labels the data without copying it. The label lets
        // WebAssembly.instantiateStreaming accept game.wasm.
        return t?b.slice(0,b.size,t):b;
      }
      // Cached URL: used where the page keeps pointing at the file (img/audio/script tags).
      async function blobURL(path){
        path=clean(path);
        if(CACHE.has(path))return CACHE.get(path);
        if(!FILES.has(path))return null;
        const b=await blobFor(path);
        if(!b)return null;
        const u=URL.createObjectURL(b);
        CACHE.set(path,u);
        return u;
      }
      // fetch/XHR: files of 16 MB or more are handed over once and released afterwards,
      // so a big game archive is not kept in memory a second time for the whole session.
      async function requestURL(path){
        path=clean(path);
        if(CACHE.has(path))return {u:CACHE.get(path),temp:false};
        if(!FILES.has(path))return null;
        const b=await blobFor(path);
        if(!b)return null;
        const u=URL.createObjectURL(b);
        if(b.size>=BIG)return {u,temp:true};
        CACHE.set(path,u);
        return {u,temp:false};
      }
      // Payloads the converter moved out of big scripts are read back through this.
      window.__embFetch=async function(p){
        const b=await blobFor(clean(p));
        if(!b)throw new Error("Embedded file missing: "+p);
        return new Response(b);
      };
    

      if(typeof window.fetch==="function"){
        const NativeFetch=window.fetch.bind(window);
        window.fetch=async function(input,init){
          const raw=typeof input==="string"?input:(input&&input.url)||(input?String(input):"");
          const p=!external(raw)?resolve(ENTRY,raw):null;
          if(p&&FILES.has(p)){
            const r=await requestURL(p);
            if(r){
              const res=NativeFetch(r.u,init);
              if(r.temp){const rel=()=>URL.revokeObjectURL(r.u);res.then(rel,rel);}
              return res;
            }
          }
          return NativeFetch(input,init);
        };
      }
    

      const NativeOpen=XMLHttpRequest.prototype.open;
      const NativeSend=XMLHttpRequest.prototype.send;
      const NativeSetHeader=XMLHttpRequest.prototype.setRequestHeader;
      const NativeOverrideMime=XMLHttpRequest.prototype.overrideMimeType;

      XMLHttpRequest.prototype.open=function(method,url,async,user,password){
        const p=(typeof url==="string"&&!external(url))?resolve(ENTRY,url):null;
        this.__bundleLocal=p&&FILES.has(p)?p:null;
        this.__bundleOpen=[method,url,async,user,password];
        this.__bundleHeaders=[];
        this.__bundleMime=null;
        if(!this.__bundleLocal){
          return NativeOpen.call(this,method,url,async,user,password);
        }
        // ZIP-backed requests are always handled asynchronously. Browsers
        // forbid responseType changes on synchronous document XHRs, while
        // Unity WebGL's loader uses asynchronous XHR.
        return NativeOpen.call(this,method,location.href,true,user,password);
      };

      XMLHttpRequest.prototype.setRequestHeader=function(name,value){
        if(this.__bundleLocal){
          this.__bundleHeaders.push([name,value]);
          return;
        }
        return NativeSetHeader.call(this,name,value);
      };

      XMLHttpRequest.prototype.overrideMimeType=function(mime){
        if(this.__bundleLocal){
          this.__bundleMime=mime;
          return;
        }
        return NativeOverrideMime.call(this,mime);
      };

      XMLHttpRequest.prototype.send=function(body){
        const p=this.__bundleLocal;
        if(!p)return NativeSend.call(this,body);

        const xhr=this;
        Promise.resolve(requestURL(p)).then(r=>{
          if(!r)throw new Error("Bundle file not found: "+p);
          const u=r.u;

          const [method,,_requestedAsync,user,password]=xhr.__bundleOpen;
          const wantedResponseType=xhr.responseType;
          const wantedTimeout=xhr.timeout;
          const wantedCredentials=xhr.withCredentials;

          // Always use an asynchronous internal request for ZIP-backed files.
          // This avoids the browser's InvalidAccessError for responseType on
          // synchronous document XHRs and matches Unity WebGL's normal loader.
          NativeOpen.call(xhr,method,u,true,user,password);

          if(wantedResponseType){
            try{xhr.responseType=wantedResponseType;}catch(_){}
          }
          if(wantedTimeout){
            try{xhr.timeout=wantedTimeout;}catch(_){}
          }
          try{xhr.withCredentials=wantedCredentials;}catch(_){}
          for(const [n,v] of xhr.__bundleHeaders)try{NativeSetHeader.call(xhr,n,v);}catch(_){}
          if(xhr.__bundleMime)try{NativeOverrideMime.call(xhr,xhr.__bundleMime);}catch(_){}
          if(r.temp)xhr.addEventListener("loadend",()=>URL.revokeObjectURL(u),{once:true});
          NativeSend.call(xhr,body);
        }).catch(err=>{
          console.error(err);
          try{xhr.dispatchEvent(new ProgressEvent("error"));}catch(_){}
          try{xhr.dispatchEvent(new ProgressEvent("loadend"));}catch(_){}
        });
      };
    

      if(typeof Worker==="function"){
        const NativeWorker=Worker;
        const BOOT=URL.createObjectURL(new Blob(["(function workerBootstrap() {\n    var queue = [], started = false, map = {};\n    var nativeImport = self.importScripts;\n    self.importScripts = function () {\n      var args = Array.prototype.map.call(arguments, function (u) {\n        var s = String(u), name = s.split(/[?#]/)[0];\n        return map[s] || map[name] || map[\"*\" + name.slice(name.lastIndexOf(\"/\") + 1)] || u;\n      });\n      return nativeImport.apply(self, args);\n    };\n    function boot(e) {\n      var d = e.data;\n      if (!started && d && d.__qvWorker) {\n        started = true;\n        self.removeEventListener(\"message\", boot);\n        map = d.map || {};\n        self.importScripts(d.url);\n        var q = queue;\n        queue = null;\n        for (var i = 0; i < q.length; i++) {\n          self.dispatchEvent(new MessageEvent(\"message\", { data: q[i].data, ports: Array.prototype.slice.call(q[i].ports || []) }));\n        }\n        return;\n      }\n      if (!started) { queue.push(e); e.stopImmediatePropagation(); }\n    }\n    self.addEventListener(\"message\", boot);\n  })();"],{type:"text/javascript"}));
        let JSMAP=null;
        const jsMap=async()=>{
          if(JSMAP)return JSMAP;
          const m={};
          for(const f of FILES){
            if(!/\.m?js$/i.test(f))continue;
            const u=await blobURL(f);
            if(u){m[f]=u;m[VORIGIN+"/"+f]=u;m["*"+f.slice(f.lastIndexOf("/")+1)]=u;}
          }
          return JSMAP=m;
        };
        const QVWorker=function(url,opts){
          const raw=typeof url==="string"?url:(url&&url.href)||String(url);
          const p=!external(raw)?resolve(ENTRY,raw):null;
          if(!p||!FILES.has(p)||(opts&&opts.type==="module"))return new NativeWorker(url,opts);
          const w=new NativeWorker(BOOT,opts);
          Promise.all([blobURL(p),jsMap()]).then(([u,map])=>w.postMessage({__qvWorker:true,url:u,map}),e=>console.error(e));
          return w;
        };
        QVWorker.prototype=NativeWorker.prototype;
        window.Worker=QVWorker;
      }
    

      if(window.AudioWorklet&&AudioWorklet.prototype.addModule){
        const nAddModule=AudioWorklet.prototype.addModule;
        const asUrl=(code)=>location.protocol==="file:"
          ?"data:text/javascript;charset=utf-8,"+encodeURIComponent(code)
          :URL.createObjectURL(new Blob([code],{type:"text/javascript"}));
        AudioWorklet.prototype.addModule=function(url,opts){
          const raw=typeof url==="string"?url:(url&&url.href)||String(url);
          const p=!external(raw)?resolve(ENTRY,raw):null;
          if(p&&FILES.has(p))return blobFor(p).then(b=>b.text()).then(code=>nAddModule.call(this,asUrl(code),opts));
          if(location.protocol==="file:"&&/^blob:/.test(raw))return fetch(raw).then(r=>r.text()).then(code=>nAddModule.call(this,asUrl(code),opts));
          return nAddModule.call(this,url,opts);
        };
      }
      if(location.protocol==="file:"&&navigator.serviceWorker){
        try{
          const sw=navigator.serviceWorker;
          sw.getRegistration=()=>Promise.resolve(undefined);
          sw.getRegistrations=()=>Promise.resolve([]);
        }catch(_){}
      }
    

      async function rewriteElement(el,attr){
        const r=el.getAttribute(attr);
        if(!r||external(r))return;
        const p=resolve(ENTRY,r);
        if(p&&FILES.has(p)){
          const u=await blobURL(p);
          if(u)el.setAttribute(attr,u);
        }
      }
      async function rewriteDOM(){
        const list=[
          ["img","src"],["audio","src"],["video","src"],["source","src"],
          ["track","src"],["iframe","src"],["embed","src"],["input","src"],
          ["object","data"],["image","href"],["use","href"]
        ];
        for(const [tag,attr] of list){
          for(const el of document.querySelectorAll(tag+"["+attr+"]")) await rewriteElement(el,attr);
        }
        for(const st of document.querySelectorAll("style")){
          let css=st.textContent||"";
          const base=st.getAttribute("data-boot-css-path")||ENTRY;
          const re=/url\((['"]?)(.*?)\1\)/gi;
          let out="",last=0,m;
          while((m=re.exec(css))){
            out+=css.slice(last,m.index);
            const p=resolve(base,m[2]);
            if(p&&FILES.has(p)){
              const u=await blobURL(p);
              out+="url("+(u||m[0])+")";
            }else out+=m[0];
            last=re.lastIndex;
          }
          out+=css.slice(last);
          st.textContent=out;
        }
      }
    

      for(const [proto,prop] of [
        [HTMLImageElement.prototype,"src"],
        [HTMLMediaElement.prototype,"src"]
      ]){
        const d=Object.getOwnPropertyDescriptor(proto,prop);
        if(!d||!d.set)continue;
        Object.defineProperty(proto,prop,{
          configurable:true,
          enumerable:d.enumerable,
          get:d.get,
          set:function(value){
            if(typeof value==="string"&&!external(value)){
              const p=resolve(ENTRY,value);
              if(p&&FILES.has(p)){
                blobURL(p).then(u=>{ if(u)d.set.call(this,u); });
                return value;
              }
            }
            return d.set.call(this,value);
          }
        });
      }
    

      // A script element with the original's attributes. Waiting uses listeners, so the page's
      // own onload/onerror attribute handlers still run.
      function scriptEl(attrs){
        const s=document.createElement("script");
        for(const [n,v] of attrs){try{s.setAttribute(n,v);}catch(_){}}
        return s;
      }
      function loaded(s){
        return new Promise(resolve=>{s.addEventListener("load",resolve,{once:true});s.addEventListener("error",resolve,{once:true});});
      }
    
await rewriteDOM();
document.title="Freegish";

            {
              const code="var Module={canvas:document.getElementById(\"canvas\"),print:console.log.bind(console),printErr:console.warn.bind(console),setStatus:function(t){var n=document.getElementById(\"status\");n&&(n.textContent=t?String(t).toUpperCase():\"\",n.style.display=t?\"grid\":\"none\")}};!function(){var t=Module.canvas;function n(){if(t.width&&t.height){var n=Math.min(window.innerWidth/t.width,window.innerHeight/t.height);t.style.width=Math.floor(t.width*n)+\"px\",t.style.height=Math.floor(t.height*n)+\"px\"}}window.addEventListener(\"resize\",n),setInterval(n,300),window.addEventListener(\"pointerdown\",(function(){t.focus()}))}()";
              const u=URL.createObjectURL(new Blob([code],{type:"text/javascript"}));
              const s=scriptEl([]);
              s.src=u;
              document.head.appendChild(s);
              await loaded(s);
              URL.revokeObjectURL(u);
            }
          

              {
                const b=await blobFor("index.js");
                if(b){
                  const u=URL.createObjectURL(b.slice(0,b.size,"text/javascript"));
                  const s=scriptEl([["async",""]]);
                  s.src=u;
                  document.head.appendChild(s);
                  await loaded(s);
                  // Kept alive: Emscripten thread workers load the main script by this URL.
                }
              }
            
}catch(e){console.error(e);alert("Bundle error: "+(e&&e.message||e));}})();